library(testthat)
library(r2dii.match)

test_check("r2dii.match")
